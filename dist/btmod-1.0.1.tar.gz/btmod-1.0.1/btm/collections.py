
"""
Collections of useful modifications for the python built-in types.
for now this no have any modificator for the python built-in types,
you can suggest new modificators for future releases
in the issues section of the GitHub page of this project (see btm.URL).
"""

import btm

__all__ = []

